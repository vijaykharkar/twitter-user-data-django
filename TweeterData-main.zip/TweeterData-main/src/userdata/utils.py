import tweepy
import pandas as pd
from src import settings as settings

consumer_key = settings.CONSUMER_KEY
consumer_secret = settings.CONSUMER_SECRET
access_key = settings.ACCESS_KEY
access_secret = settings.ACCESS_SECRET

import pdb
def tweet_download(screen_name):
    try:
        auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
        auth.set_access_token(access_key, access_secret)
        api = tweepy.API(auth)

        tweetsData = []
        final_result = pd.DataFrame()
        try:
            u=api.get_user(screen_name)
            if(u.screen_name):
                new_tweets = api.user_timeline(screen_name = screen_name,count=200, tweet_mode="extended")
                tweetsData.extend(new_tweets)
                keyOld = tweetsData[-1].id - 1
                final_result = []
                while len(new_tweets) > 0:
                    new_tweets = api.user_timeline(screen_name = screen_name,count=200,max_id=keyOld,tweet_mode="extended")
                    tweetsData.extend(new_tweets)
                    keyOld = tweetsData[-1].id - 1  
                for tweet in tweetsData:
                    tweet_id = tweet.id_str
                    tweet_date = tweet.created_at
                    if tweet.full_text.startswith("RT @"):
                      try:
                        try:
                            moduler = (tweet.text).split(":")
                        except:
                            moduler = (tweet.full_text).split(":")
                        moduler = moduler[0]
                        tweet = tweet.retweeted_status.full_text
                        tweet = moduler+":"+ tweet
                      except:
                        tweet = tweet.text
                    else:
                      try: 
                          tweet = tweet.text
                      except: 
                          tweet = tweet.full_text
                    final_result.append([tweet_id,tweet_date,tweet])

                final_result = pd.DataFrame(final_result)
                final_result = final_result.rename(columns={0: "id", 1: "Date Time",2:"Tweets"})
                return final_result
        except:
            return final_result
    except:
        final_result = pd.DataFrame()
        return final_result
