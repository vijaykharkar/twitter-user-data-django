from django.apps import AppConfig


class UserdataConfig(AppConfig):
    name = 'userdata'
