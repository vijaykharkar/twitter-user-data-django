from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from .utils import tweet_download
import pandas as pd
import numpy as np
import csv,io
from django.views.generic.base import TemplateView
from django.contrib import messages
from django.shortcuts import redirect


# Create your views here.
class funct(TemplateView):
    template_name = "info.html"

    def get_context_data(self, **kwargs):
        context = super(funct, self).get_context_data(**kwargs)
        return context

    def post(self, request, *args, **kwargs):
        q = request.POST.get('user_name')
        checkbox = request.POST.get('retweet')
        try:
            if checkbox:
                results = tweet_download(q)
                if (len(results)):
                    messages.success(request, 'Data Found!')
                    response = HttpResponse(content_type='text/csv')
                    response['Content-Disposition'] = 'attachment; filename=filename.csv'
                    results.to_csv(path_or_buf=response,sep=',',float_format='%.2f',index=False,decimal=".")
                    return response
                else:
                    messages.error(request, 'Please Enter Correct Username')
                    redirect('/')
            else:
                results = tweet_download(q)
                if (len(results)):
                    results = results[~results['Tweets'].astype(str).str.startswith('RT')]
                    messages.success(request, 'Data Found!')
                    response = HttpResponse(content_type='text/csv')
                    response['Content-Disposition'] = 'attachment; filename=filename.csv'
                    results.to_csv(path_or_buf=response,sep=',',float_format='%.2f',index=False,decimal=".")
                    return response
                else:
                    messages.error(request, 'Please Enter Correct Username')
                    redirect('/')

        except:
            redirect('/')
        return render(request, self.template_name)